@echo off
setlocal DisableDelayedExpansion
set "PYTHONUTF8=1"
pushd "%~dp0"
if errorlevel 1 exit /b 1
set "R7_PY="
set "R7_EXTRA="
if not "%~1"=="" if exist "%~1\.venv\Scripts\python.exe" set "R7_PY=%~1\.venv\Scripts\python.exe"
if not defined R7_PY if exist "%USERPROFILE%\OneDrive\Documents\GitHub\FX-M1-Signal\mt5_bridge\.venv\Scripts\python.exe" set "R7_PY=%USERPROFILE%\OneDrive\Documents\GitHub\FX-M1-Signal\mt5_bridge\.venv\Scripts\python.exe"
if defined R7_PY goto run
python -c "import sys; assert sys.version_info >= (3,10)" >nul 2>&1
if not errorlevel 1 (
 set "R7_PY=python"
 goto run
)
py -3 -c "import sys; assert sys.version_info >= (3,10)" >nul 2>&1
if not errorlevel 1 (
 set "R7_PY=py"
 set "R7_EXTRA=-3"
 goto run
)
echo Python 3.10 or newer was not found. Install Python 3.12 x64, then run this installer again.
if not "%R7_NO_PAUSE%"=="1" pause
popd
exit /b 1
:run
"%R7_PY%" %R7_EXTRA% "%~dp0update_bridge.py" --rollback %*
set "R7_EXIT=%ERRORLEVEL%"
if not "%R7_EXIT%"=="0" echo Update failed. Keep your existing Bridge folder and state. See r73-install.log in the selected folder.
if not "%R7_NO_PAUSE%"=="1" pause
popd
exit /b %R7_EXIT%
