from __future__ import annotations
from dataclasses import dataclass, asdict
from decimal import Decimal, ROUND_FLOOR, ROUND_CEILING
from datetime import datetime, timezone, timedelta
from .model import Config, Quote, Decision, Blocked, number
from .mt5_adapter import MAGIC

LOCAL_DAY = timezone(timedelta(hours=5))


def money(deal):
    return sum(number(deal.get(k,0), k) for k in ('profit','commission','swap','fee'))


def realized_net(deals):
    """Net result of closed volume, allocating its share of opening expenses.

    Remaining live volume is charged separately by the round-trip fee reserve.
    A partial close must neither drop nor double count its opening commission.
    """
    groups={}
    for d in deals:
        if d.get('type') not in (0,1):continue
        g=groups.setdefault(d['position_id'],dict(opened=0.,closed=0.,opening=0.,exits=0.))
        if d.get('entry')==0:
            g['opened']+=number(d['volume'],'opening volume');g['opening']+=money(d)
        elif d.get('entry') in (1,3):
            g['closed']+=number(d['volume'],'closing volume');g['exits']+=money(d)
    return sum(g['exits']+g['opening']*min(1.,g['closed']/g['opened'])
               if g['opened']>0 else g['exits'] for g in groups.values())


def symbol_key(value):
    return str(value or '').replace('/','').replace(' ','').upper()


def estimate_roundtrip_fee_per_lot(deals, symbol=None):
    """Estimate completed round-trip broker commission/fees per lot.

    Uses any completed MT5 position for the same symbol, not only EC1 trades, because
    broker commission is an account/instrument property. Profit and swap are excluded.
    """
    wanted=symbol_key(symbol) if symbol else ''
    groups={}
    for d in sorted(deals,key=lambda x:(x.get('time_msc',0),x.get('ticket',0))):
        if d.get('type') not in (0,1):continue
        if wanted and symbol_key(d.get('symbol'))!=wanted:continue
        pid=int(d.get('position_id',0) or 0)
        if not pid:continue
        g=groups.setdefault(pid,dict(opened=0.,closed=0.,cost=0.))
        volume=max(0.,float(d.get('volume',0) or 0))
        if d.get('entry')==0:g['opened']+=volume
        elif d.get('entry') in (1,3):g['closed']+=volume
        g['cost']+=abs(float(d.get('commission',0) or 0))+abs(float(d.get('fee',0) or 0))
    cost=0.;volume=0.
    for g in groups.values():
        if g['opened']>0 and g['closed']>=g['opened']-1e-8:
            cost+=g['cost'];volume+=g['opened']
    if volume<=0:return None
    return cost/volume


def day_start(now):
    t=datetime.fromtimestamp(now, LOCAL_DAY)
    return t.replace(hour=0,minute=0,second=0,microsecond=0).timestamp()


def exit_evidence(deals):
    """Preserve every broker exit fill, including mixed partial-close reasons.

    This is observational metadata only. Never replace Engine's first exit intent,
    estimate a cause from the stop price, or change monetary reconciliation.
    """
    exits=[];codes=[];labels=[]
    for d in sorted(deals,key=lambda x:(x.get('time_msc',0),x.get('ticket',0))):
        if d.get('type') not in (0,1) or d.get('entry') not in (1,3):continue
        code=d.get('reason_code') or 'UNKNOWN'
        reason=d.get('reason')
        label=d.get('reason_label') or ('Причина не получена от MT5' if reason is None
                                         else 'Неизвестный код MT5: '+str(reason))
        row={k:d.get(k) for k in ('ticket','position_id','entry','time_msc','raw_time_msc',
                                'volume','price','profit','commission','swap','fee','comment')}
        row.update(reason=reason,reason_code=code,reason_label=label,
                   reason_source=d.get('reason_source','MISSING' if reason is None else 'MT5_DEAL_REASON'))
        exits.append(row)
        if code not in codes:codes.append(code)
        if label not in labels:labels.append(label)
    return dict(source='MT5_HISTORY',complete=bool(exits) and all(x['reason'] is not None for x in exits),
                reason_codes=codes,text='; '.join(labels) if labels else 'Нет закрывающих сделок MT5',deals=exits)


def ledger(deals, open_positions=()):
    """Group by position, include opening expenses; never count partial exits as new trades."""
    groups={}
    for d in sorted(deals, key=lambda x:(x['time_msc'],x['ticket'])):
        if d.get('type') not in (0,1):
            continue
        key=int(d['position_id'])
        if not key:
            continue
        g=groups.setdefault(key,dict(position_id=key,net=0.,opened=0.,closed=0.,time=0,
            time_msc=0,last_ticket=0,open_time=0,side='',symbol=d['symbol'],magic=d.get('magic',0),exit_deals=[]))
        g['net']+=money(d)
        if d['entry']==0:
            g['opened']+=d['volume']
            if not g['open_time']:
                g['open_time']=d['time_msc']/1000;g['side']='BUY' if d['type']==0 else 'SELL'
        elif d['entry'] in (1,3):
            g['exit_deals'].append(d)
            g['closed']+=d['volume'];g['time']=d['time_msc']/1000
            g['time_msc']=d['time_msc'];g['last_ticket']=d['ticket']
        else:
            raise Blocked('История содержит netting/reversal, нужен DEMO hedging')
    live={int(p.get('identifier',p['ticket'])) for p in open_positions}
    rows=[]
    for key,g in groups.items():
        if key not in live and g['closed']>0 and g['opened']<=0:
            raise Blocked('Неполная история: отсутствует открытие закрытой позиции')
        if key not in live and g['opened']>0 and g['closed']>=g['opened']-1e-8:
            g['broker_exit']=exit_evidence(g.pop('exit_deals'))
            g['volume']=g['opened'];rows.append(g)
    return sorted(rows,key=lambda x:(x['time_msc'],x['last_ticket']))


def summary(rows):
    net=[float(x['net']) for x in rows]
    return dict(profit=sum(x for x in net if x>0),loss=sum(x for x in net if x<0),
                net=sum(net),count=len(net),wins=sum(x>0 for x in net))


def risk_state(account, positions, deals, cfg: Config, now: float, ack=(0,0), daily_latch=''):
    """Only EC1-owned exposure is considered for EC1 risk telemetry.

    Legacy V10/manual trades remain visible in the account and journal but never create
    DAILY_LOSS, DRAWDOWN or LOSS_STREAK entry blocks for EC1. Campaign stop risk and
    margin are enforced in plan_order().
    """
    cfg.validate()
    actual=str(account.get('type','UNKNOWN')).upper()
    if actual!=cfg.account_mode:
        raise Blocked(f'Профиль {cfg.account_mode}, а MT5 {actual}: проверьте режим счёта')
    if actual not in ('DEMO','REAL'):
        raise Blocked('Поддерживаются только DEMO или REAL; contest запрещён')
    if account.get('margin_mode')!='HEDGING':
        raise Blocked('Для отдельных ступеней нужен hedging-счёт')
    if not account.get('trade_allowed'):
        raise Blocked('Торговля отключена в MT5')

    owned_positions=[p for p in positions if int(p.get('magic',0) or 0)==MAGIC]
    owned_deals=[d for d in deals if int(d.get('magic',0) or 0)==MAGIC]
    rows=ledger(owned_deals,owned_positions)
    series=[r for r in rows if (r['time_msc'],r['last_ticket'])>tuple(ack)]
    streak=0
    for r in reversed(series):
        if r['net']<0:streak+=1
        else:break
    closed_today=sum(money(d) for d in owned_deals if d.get('type') in (0,1) and d['time_msc']/1000>=day_start(now))
    floating=sum(number(p.get('profit',0),'EC1 floating')+number(p.get('swap',0),'EC1 swap') for p in owned_positions)
    base=cfg.base(account)
    day=datetime.fromtimestamp(now,LOCAL_DAY).date().isoformat()
    return dict(allowed=True,blocks=[],daily_pl=closed_today,floating=floating,
        daily_loss_pct=max(0,-(closed_today+floating))/base*100,
        drawdown_pct=max(0,-floating)/base*100,consecutive_losses=streak,
        ack_supported=False,can_acknowledge=False,
        last_closing_ticket=rows[-1]['last_ticket'] if rows else 0,
        last_closing_time_msc=rows[-1]['time_msc'] if rows else 0,
        last_closing_time=rows[-1]['time'] if rows else 0,
        base=base,campaign_budget=cfg.budget(account),day=day)


@dataclass(frozen=True)
class Plan:
    side: int
    symbol: str
    volume: float
    entry: float
    stop: float
    adverse_entry: float
    adverse_stop: float
    risk: float
    total_risk: float
    margin: float
    event_id: str


def quantize(value,step,up=False):
    d=Decimal(str(value));s=Decimal(str(step))
    return float((d/s).to_integral_value(rounding=ROUND_CEILING if up else ROUND_FLOOR)*s)


def plan_order(broker, cfg: Config, account, info, q: Quote, d: Decision, positions,
               campaign, now):
    cfg.validate();q.validate(now)
    if not cfg.approved or cfg.fee_per_lot is None:
        raise Blocked('Подтвердите риск и комиссию профиля счёта')
    if d.signal not in ('BUY','SELL') or not d.event_id:
        raise Blocked('Нет нового подтверждённого входа')
    actual=str(account.get('type','UNKNOWN')).upper()
    if actual!=cfg.account_mode:
        raise Blocked(f'Профиль {cfg.account_mode}, а MT5 {actual}: режим счёта не совпадает')
    if actual not in ('DEMO','REAL') or account.get('margin_mode')!='HEDGING':
        raise Blocked('Исполнение только на DEMO/REAL hedging')
    if not account.get('trade_allowed'):
        raise Blocked('Торговля MT5 выключена')
    symbol=info['name'];point=number(info['point'],'point',positive=True)
    tick=number(info['tick_size'],'tick_size',positive=True)
    pip=point*10 if info['digits'] in (3,5) else point
    if q.spread/number(d.atr,'ATR',positive=True)>cfg.max_spread_atr:
        raise Blocked('Спред слишком велик относительно текущей волатильности')
    letters=''.join(ch for ch in symbol.upper() if ch.isalpha())
    currencies={'USD','EUR','GBP','JPY','CHF','AUD','CAD','NZD','NOK','SEK','DKK','SGD','HKD','MXN','ZAR','TRY','PLN','CZK','HUF'}
    is_fx=len(letters)>=6 and letters[:3] in currencies and letters[3:6] in currencies
    if is_fx and q.spread/pip>cfg.spread_pips:
        raise Blocked('FX-спред превышает выбранный предел')
    if len(positions)>=cfg.technical_position_fuse:
        raise Blocked('Технический предохранитель: слишком много позиций')
    if cfg.optional_position_limit and len(positions)>=cfg.optional_position_limit:
        raise Blocked('Достигнут выбранный дополнительный лимит позиций')
    number(d.stop,'stop',positive=True);number(d.atr,'ATR',positive=True)
    side=d.side;price=q.ask if side==1 else q.bid
    if side not in (-1,1) or (price-d.stop)*side<=0:
        raise Blocked('Некорректная сторона стопа')
    distance=max(int(info['stops_level'])*point+tick,tick)
    # Final broker-valid stop BEFORE any volume calculation.
    stop=min(d.stop,q.bid-distance) if side==1 else max(d.stop,q.ask+distance)
    stop=quantize(stop,tick,up=side==-1)
    reserve=max(cfg.slippage_ticks*tick,q.spread)
    adverse_entry=price+side*reserve
    adverse_stop=stop-side*reserve
    vmin=number(info['volume_min'],'volume_min',positive=True)
    vmax=number(info['volume_max'],'volume_max',positive=True)
    step=number(info['volume_step'],'volume_step',positive=True)
    budget=float(campaign.get('budget',cfg.budget(account))) if campaign else cfg.budget(account)
    budget=min(budget,cfg.budget(account))
    realized=number(campaign.get('realized',0),'campaign realized P/L') if campaign else 0.
    spent=max(0,-realized)
    running_risk=spent
    net=realized
    for p in positions:
        ps=int(p['side']);psl=number(p['sl'],'existing SL',positive=True)
        if ps!=side or p['symbol']!=symbol:
            raise Blocked('Кампания другого направления/инструмента')
        risk=-number(broker.calc_profit(ps,p['symbol'],p['volume'],p['price_open'],psl-ps*reserve),'position stop P/L')
        running_risk+=max(0,risk)+cfg.fee_per_lot*p['volume']
        net+=number(p['profit'],'floating P/L')+number(p.get('swap',0),'swap')-cfg.fee_per_lot*number(p['volume'],'volume',positive=True)
    if positions:
        if d.entry_class=='PROBE': raise Blocked('Probe разрешён только как первый вход кампании')
        if not cfg.dynamic_adds: raise Blocked('Режим одного входа: добавления выключены')
        if net<=0: raise Blocked('Кампания не в чистом плюсе: усреднение запрещено')
        if not campaign: raise Blocked('Нельзя добавлять без сохранённой кампании')
        if (price-campaign['last_entry'])*side<d.atr*campaign['add_step_atr']:
            raise Blocked('Цена не прошла следующий шаг в сторону кампании')
    unit_loss=-number(broker.calc_profit(side,symbol,vmin,adverse_entry,adverse_stop),'planned P/L')/vmin+cfg.fee_per_lot
    if unit_loss<=0: raise Blocked('Не удалось оценить денежный риск стопа')
    available=budget-running_risk
    effective_lot_cap=min(cfg.lot_cap,cfg.probe_lot_cap) if d.entry_class=='PROBE' else cfg.lot_cap
    if cfg.volume_mode=='FIXED':
        volume=number(cfg.lot_cap,'объём позиции',positive=True)
        units=Decimal(str(volume))/Decimal(str(step))
        if abs(units-units.to_integral_value())>Decimal('0.00000001'):
            raise Blocked(f'Выбранный объём {volume:g} не соответствует шагу MT5 {step:g}')
        if not vmin-1e-10<=volume<=vmax+1e-10:
            raise Blocked(f'Выбранный объём {volume:g}: допустимый объём MT5 {vmin:g} … {vmax:g}')
        if unit_loss*volume>available+1e-7:
            maximum=max(0,quantize(min(vmax,available/unit_loss),step))
            raise Blocked(f'Лот {volume:g} требует {unit_loss*volume:.2f} USD риска; доступно {max(0,available):.2f} USD. '
                          f'Максимум по риску {maximum:g}; выбранный лот не изменён')
    else:
        volume=quantize(min(vmax,effective_lot_cap,available/unit_loss),step)
    if volume<vmin-1e-10 or volume<=0:
        raise Blocked(f'Минимальный лот {vmin:g} не помещается в остаток риска {max(0,available):.2f} USD')
    risk=unit_loss*volume
    if risk+running_risk>budget+1e-7:
        raise Blocked('Общий риск кампании превышен')
    margin=number(broker.calc_margin(side,symbol,volume,price),'margin')
    if margin<0: raise Blocked('Некорректная маржа')
    existing_margin=sum(number(broker.calc_margin(p['side'],p['symbol'],p['volume'],p['price_open']),'existing margin') for p in positions)
    if margin>number(account['margin_free'],'free margin',positive=True)*.8 or margin+existing_margin>cfg.base(account)*cfg.margin_fraction:
        raise Blocked('Недостаточно маржи в выбранной базе испытаний')
    return Plan(side,symbol,volume,price,stop,adverse_entry,adverse_stop,risk,running_risk+risk,margin,d.event_id)
